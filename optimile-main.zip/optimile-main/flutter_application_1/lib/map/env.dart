class Env {
  // Google Maps / Directions API key
  static const googleMapsApiKey = 'AIzaSyCUqESrPfdNpQSCVoPITrphmbvic4hVKfk';

  // Default location (optional)
  static const defaultLat = 30.0444;
  static const defaultLng = 31.2357;

  // Directions API URL
  static const directionsApiUrl =
      'https://maps.googleapis.com/maps/api/directions/json';
}

